
#include <iostream>

//include and lib
#include "../omem/omem.h"
#ifdef _DEBUG
#pragma comment( lib,"../x64/Debug/omem.lib")
#else
#pragma comment( lib,"../x64/Release/omem.lib")
#endif


void callanother()
{
	void* callerThisPtr = nullptr;

    std::cout << "Caller class 'this' value (from register): " << callerThisPtr << std::endl;
}

class MyClass {
public:
    void Callfn() {
        callanother();
    }
};

void test_outofboundread();
void test_outofboundwrite();
void test_autolock();

int main()
{
	std::cout << "omem lib usage tests !\n";

	MyClass obj1, obj2;
	obj1.Callfn();

	//test_outofboundread();
	//test_outofboundwrite();


	test_autolock();
}

// override new op for compatibility 
#define _OMEM_OP_OVERRIDE
void test_outofboundread()
{
	// no owner boundry check
	std::cout << "omem : test out of bound read\n";
	int* val = new int[5] {0};
	for (int i = 0; i < 6; i++)
	{
		int n = val[i];
	}
}

void test_outofboundwrite()
{
	// no owner boundry check
	std::cout << "omem : test out of bound write\n";
	int* val = new int[5];
	for (int i = 0; i < 6; i++)
	{
		val[i] = 1;
	}
}