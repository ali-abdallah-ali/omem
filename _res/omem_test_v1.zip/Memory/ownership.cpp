#include <iostream>

//include and lib
#include "../omem/omem.h"

#define new _OMEM_NEW_AUTOLOCK

class a {
public:
	a() { m_pData = nullptr; }
	~a() { delete[] m_pData; }

	void alloc()
	{
		m_pData = new int[100];
		//owner write test
		m_pData[50] = 1;

		//auto lock and fn end
	}

	void unlockandwrite()
	{
		_omem_scopelock omemlock = _omem_scopelock();
		omem_unlock(m_pData, omemlock, this);
		m_pData[50] = 1;
	}

	int* m_pData;
};

class b {
public:
	b() {}
	~b() {}

	void tryread(int* pData)
	{
		int val = pData[50];
	}

	void trywrite(int* pData)
	{
		pData[50] = 1;
	}
};
void test_autolock()
{
	a owner;
	b other;

	owner.alloc();
	other.tryread(owner.m_pData);
	other.trywrite(owner.m_pData);

	owner.unlockandwrite();
}
#undef _OMEM_OP_OVERRIDE_AUTOLOCK